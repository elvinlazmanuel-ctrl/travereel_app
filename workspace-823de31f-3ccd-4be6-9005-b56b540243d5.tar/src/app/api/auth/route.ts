import { NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { withRateLimit } from '@/lib/api-utils'
import { validateBody, loginSchema, registerSchema } from '@/lib/validation'

export async function POST(request: Request) {
  try {
    // Rate limit auth operations
    const rateLimitResponse = withRateLimit(request, 'auth')
    if (rateLimitResponse) return rateLimitResponse

    const body = await request.json()
    const { action } = body

    if (action === 'register') {
      const validation = validateBody(registerSchema, body)
      if (!validation.success) {
        return NextResponse.json(
          { error: validation.error },
          { status: 400 }
        )
      }

      const { email, password, username, name } = validation.data

      // Check if user already exists
      const existingUser = await db.user.findFirst({
        where: {
          OR: [{ email }, { username }],
        },
      })

      if (existingUser) {
        return NextResponse.json(
          { error: 'Email or username already taken' },
          { status: 409 }
        )
      }

      // Create user
      const user = await db.user.create({
        data: {
          email,
          username,
          name,
          password, // In production, hash with bcrypt
          avatar: null,
          bio: null,
          isPrivate: false,
        },
      })

      return NextResponse.json({
        user: formatUser(user),
      })
    }

    if (action === 'login') {
      const validation = validateBody(loginSchema, body)
      if (!validation.success) {
        return NextResponse.json(
          { error: validation.error },
          { status: 400 }
        )
      }

      const { email, password } = validation.data

      // Find user by email
      const user = await db.user.findUnique({
        where: { email },
      })

      if (!user || user.password !== password) {
        return NextResponse.json(
          { error: 'Invalid email or password' },
          { status: 401 }
        )
      }

      if (user.isBanned) {
        return NextResponse.json(
          { error: 'This account has been suspended' },
          { status: 403 }
        )
      }

      return NextResponse.json({
        user: formatUser(user),
      })
    }

    return NextResponse.json(
      { error: 'Invalid action. Use "login" or "register"' },
      { status: 400 }
    )
  } catch (error) {
    console.error('Auth error:', error)
    return NextResponse.json(
      { error: 'Internal server error' },
      { status: 500 }
    )
  }
}

function formatUser(user: {
  id: string
  email: string
  username: string
  name: string
  avatar: string | null
  bio: string | null
  isPrivate: boolean
  isBanned: boolean
  role: string
  currency: string
  travelType: string
  language: string
  notificationsEnabled: boolean
  activityStatus: boolean
  darkMode: boolean
}) {
  return {
    id: user.id,
    email: user.email,
    username: user.username,
    name: user.name,
    avatar: user.avatar,
    bio: user.bio,
    isPrivate: user.isPrivate,
    isBanned: user.isBanned,
    role: user.role,
    currency: user.currency,
    travelType: user.travelType,
    language: user.language,
    notificationsEnabled: user.notificationsEnabled,
    activityStatus: user.activityStatus,
    darkMode: user.darkMode,
  }
}
